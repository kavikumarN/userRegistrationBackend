module.exports={
    mongoURI: "mongodb://localhost:27017/carnival",
    secret:"carnivaldata",
    otpString:"Your OTP Verification Code is ",
    smsurl: 'http://sms.skyappzsoftware.in/sendsms/',
    smsToken: '9f46b20ec52f60f75a65f26504602238'
}