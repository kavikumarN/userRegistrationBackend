import React from "react";

const NavBar = () => {
    return (
      

// <section className="rt-banner-area">
//     <div className="single-rt-banner rt-banner-height" style={{backgroundImage: assets/images/all-img/banner01.png}}>
//         <div className="container">
//             <div className="row  rt-banner-height align-items-center">
//                 <div className="col-lg-9">
//                     <div className="rt-banner-content">
//                         <h2 className="wow fade-in-bottom" data-wow-duration="1s" data-wow-delay="0.5s">
//                            Online Event Booking <br/> Application
							
//                         </h2><br/>
//                         <p className="wow fade-in-top">
//                             A holistic platform that gives your team all of the needed tools to <br/>create rewarding events, while surfacing insights to help your events <br/> grow in ways you never thought were possible.
//                         </p>
                    
//         <div className="rt-banner-searchbox standard-search wow fade-in-bottom" data-wow-duration="1s" data-wow-delay="1s">
//             <div className="tab-content" id="myTabContent">
//                 <div className="tab-pane show active" id="rt-item_a_first" role="tabpanel" aria-labelledby="rt-item_a_first">
//                     <form action="#">
                       
//                         <div className="rt-input-group">
//                             <div className="single-input  col-rt-in-3">
//                                 <select className="rt-selectactive banner-select" name="from" style={{width: 100}}>
// 							        <option value="1">Category</option>
//                                     <option value="1">Apparel Shopping</option>
//                                     <option value="2">Apparel Rent</option>
//                                     <option value="3">Venue</option>
//                                     <option value="4">Decorators</option>
//                                     <option value="6">Catering</option>
//                                     <option value="7">Beauty Services</option>
//                                     <option value="8">Honeymoon Packages</option>
// 								    <option value="4">Photography</option>
//                                     <option value="6">Music/Entertainment</option>
//                                     <option value="7">Vehicle Rentals</option>
//                                     <option value="8">Invitation</option>
// 							        <option value="4">Travel Services</option>
//                                     <option value="6">Jewellery</option>
                                  
//                                 </select>
//                                 <span className="input-iconbadge"><i style="color:#f51d2c;"className="fa fa-list-ul" aria-hidden="true"></i></span>
//                             </div>
//                             <div className="single-input  col-rt-in-3">
//                                 <select className="rt-selectactive banner-select" name="to" style={{width: 100}}>
//                                     <option value="1">Location</option>
//                                     <option value="2"></option>
//                                     <option value="3"></option>
//                                     <option value="4"></option>
//                                     <option value="5"></option>
//                                     <option value="6"></option>
//                                     <option value="7"></option>
//                                     <option value="8"></option>
//                                 </select>
//                                 <span className="input-iconbadge"><i style={{color:"#f51d2c"}} className="fa fa-map-marker" aria-hidden="true"></i></span>
//                             </div>
//                             <div className="single-input  col-rt-in-3">
//                                 <input type="text" className="form-control rt-date-picker has-icon" placeholder="Date start"/>
//                                 <span className="input-iconbadge"><i style={{color:"#f51d2c"}} className="icofont-ui-calendar"></i></span>
//                             </div>
//                             <div className="single-input  col-rt-in-3">
//                                 <input type="text" className="form-control rt-date-picker has-icon" placeholder="Date End"/>
//                                 <span className="input-iconbadge"><i style={{color:"#f51d2c"}} className="icofont-ui-calendar"></i></span>
//                             </div>
//                             <div className="single-input  col-rt-in-1">
                              
//                             <a href="category.html"><button type="submit"><i className="icofont-search"></i></button></a>
                       
//                         </div>
//                     </form>
//                 </div>
            
//             </div>
//         </div>

    
//         <ul className="nav serachnavs wow fade-in-bottom" id="rtMultiTab" role="tablist" data-wow-duration="1.5s" data-wow-delay="1.5s">
//             <li className="nav-item">
//                 <a className="nav-link active" id="first-tab" data-target="#rt-item_b_first" data-secondary="#rt-item_a_first"
//                     data-toggle="tab" href="#first" role="tab" aria-controls="first-tab" aria-selected="false">
//                     <i className="fa fa-building-o" aria-hidden="true"></i>
//                     <span>Search here</span>
//                 </a>
//             </li>
//             <li className="nav-item">
//                 <a className="nav-link inactive" id="second-tab" data-target="#rt-item_b_second" data-secondary="#rt-item_a_second"
//                     data-toggle="tab" href="#second" role="tab" aria-controls="second-tab" aria-selected="true">
        
//                    <i className="fas fa-campfire"></i>
//                     <span>Catering</span>
//                 </a>
//             </li>
//             <li className="nav-item">
//                 <a className="nav-link inactive" id="third-tab" data-target="#rt-item_b_thrid" data-secondary="#rt-item_a_third"
//                     data-toggle="tab" href="#third" role="tab" aria-controls="third-tab" aria-selected="false">
//                     <i className="icofont-car-alt-4"></i>
//                     <span>Decorators</span>
//                 </a>
//             </li>
//             <li className="nav-item">
//                 <a className="nav-link inactive" id="four-tab" data-target="#rt-item_b_four" data-secondary="#rt-item_a_four"
//                     data-toggle="tab" href="#four" role="tab" aria-controls="four-tab" aria-selected="false">
//                     <i className="icofont-train-line"></i>
//                     <span>Photography</span>
//                 </a>
//             </li>
// 			 <li className="nav-item">
//                 <a className="nav-link inactive" id="four-tab" data-target="#rt-item_b_four" data-secondary="#rt-item_a_four"
//                     data-toggle="tab" href="#four" role="tab" aria-controls="four-tab" aria-selected="false">
//                     <i className="icofont-train-line"></i>
//                     <span>Photography</span>
//                 </a>
//             </li>
//         </ul>
//                     </div>
//                 </div>
//             </div>
//         </div>
//     </div>
// </section>


// {/* <!--  ========= Counter Start ======================== --> */}
// <div className="counter-area">
//     <div className="container">
//         <div className="row">
//           <div className="col-lg-4 col-md-6 col-12">
//                 <div className="media counter-box-1 align-items-center wow fadeInUp">
//                     <img src="assets/images/counter-icons/counter_iocn_1.png" alt="counter_iocn" draggable="false"/>
//                     <div className="media-body">
//                         <h5>Trusted Members</h5>
//                         <h6><span className="counter">90,000</span><span>+</span></h6>
//                     </div>
//                 </div>
//             </div>
//             {/* <!-- /.col-lg-4 --> */}
//             <div className="col-lg-4 col-md-6 col-12" >
//                 <div className="media counter-box-1 align-items-center wow fadeInUp" data-wow-duration="1.5s">
//                     <img src="assets/images/counter-icons/counter_iocn_2.png" alt="counter_iocn" draggable="false"/>
//                     <div className="media-body">
//                         <h5>Trusted Members</h5>
//                         <h6><span className="counter">2,00</span></h6>
//                     </div>
//                 </div>
//             </div>
//             {/* <!-- /.col-lg-4 --> */}
//             <div className="col-lg-4 col-md-6 col-12">
//                 <div className="media counter-box-1 align-items-center wow fadeInUp" data-wow-duration="2s">
//                 <img src="assets/images/counter-icons/counter_iocn_3.png" alt="counter_iocn" draggable="false"/>
//                     <div className="media-body">
//                         <h5>Trusted Members</h5>
//                         <h6><span className="counter">80,000</span><span>+</span></h6>
//                     </div>
//                 </div>
//             </div>
//             {/* <!-- /.col-lg-4 --> */}
    
//         </div>
//         {/* <!-- /.row --> */}
//     </div>
//     {/* <!-- /.container --> */}
// </div>
// {/* <!-- /.counter --> */}

// {/* <!--    ===========Services Area start========== --> */}
// <section className="emigr-services-area rtbgprefix-contain" style="background-image: url(assets/images/backgrounds/dotbg.png)">
//     <div className="spacer-bottom"></div>
//     {/* <!-- /.spacer-bottom --> */}
//     <div className="container">
//         <div className="row">
//             <div className="col-lg-8 text-center mx-auto">
//                 <div className="rt-section-title-wrapper">
//                     <h2 className="rt-section-title">
//                         <span>WHY Choose Namma Carnival?</span>
//                         Our Core Values
//                     </h2>
//                     {/* <!-- /.rt-section-title --> */}
//                     <p>Namma Carnival is recognized as the fastest-growing startup in India. We are a mobile marketplace for local services. We help customers hire trusted professionals for all their service needs.</p>
//                 </div>
//                 {/* <!-- /.rt-section-title-wrapper- --> */}
//             </div>
//             {/* <!-- /.col-lg-12 --> */}
//         </div>
//         {/* <!-- /.row --> */}
//         <div className="section-title-spacer"></div>
//         {/* <!-- /.section-title-spacer --> */}
//         <div className="row">
//             <div className="col-lg-4 col-md-6 mx-auto text-center">
//                 <div className="services-box-1 wow fade-in-bottom">
//                     <div className="services-thumb">
//                         <img src="assets/images/icons-image/3.png" alt="" draggable="false"/>
//                     </div>
//                     {/* <!-- /.services-thumb --> */}
//                     <h4>SIMPLE SELECTION PROCESS</h4>
//                     <p>Simple selection process with all adequate details and descriptions to help you choose a venue or a vendor that perfectly match your requirement.orld.</p>
//                 </div>
//                 {/* <!-- /.services-box-1 --> */}
//             </div>
//             {/* <!-- /.col-lg-4 --> */}
//             <div className="col-lg-4 col-md-6 mx-auto text-center">
//                 <div className="services-box-1 wow fade-in-bottom" data-wow-duration="1.5s">
//                     <div className="services-thumb">
//                        <img src="assets/images/service-icons/s_icon_3.png" alt="" draggable="false"/>
//                     </div>
//                     {/* <!-- /.services-thumb --> */}
//                     <h4>PROVIDE UPDATED & ACCURATE INFORMATION</h4>
//                     <p>Accurate Information about all  Event Hall Spaces along with details of wedding and other service providers on our site.</p>
//                 </div>
//                 {/* <!-- /.services-box-1 --> */}
//             </div>
//             {/* <!-- /.col-lg-4 --> */}
//             <div className="col-lg-4 col-md-6 mx-auto text-center">
//                 <div className="services-box-1 wow fade-in-bottom" data-wow-duration="2s">
//                     <div className="services-thumb">
//                    <img src="assets/images/service-icons/s_icon_1.png" alt="" draggable="false"/>
//                     </div>
//                     {/* <!-- /.services-thumb --> */}
//                     <h4>ENSURING QUICK &   ONTIME BOOKINGS</h4>
//                     <p>Quick and on time bookings enabled by our site's features and a dedicated team to help, assist and manage your venue and service provider bookings.</p>
//                 </div>
//                 {/* <!-- /.services-box-1 --> */}
//             </div>
//             {/* <!-- /.col-lg-4 --> */}
//         </div>
//         {/* <!-- /.row --> */}
//     </div>
//     {/* <!-- /.container --> */}
//     <div className="spacer-bottom"></div>
//     {/* <!-- /.spacer-bottm --> */}
// </section>

// {/* <!--  ============Deal Area Start=============== --> */}


//  <section className="deal-area   rtbgprefix-full bg-hide-md" style="background-image: url(assets/images/backgrounds/bgshapes_1.png)">
//     <div className="container-fluid p-0">
//        <div className="deal-carosel-active owl-carousel">
//             <div className="row single-deal-carosel align-items-center">
//                 <div className="col-lg-5">
//                     <div className="deal-bg" style="background-image: url(assets/images/all-img/deal-bg.jpg)">
//                         <div className="inner-content">
//                             <h4 data-animation="fadeInDown" data-duration=".2s" data-delay=".4s">14 Day Classic Tour of Thailand & Beaches</h4>
//                             <p data-animation="fade-in-bottom" data-duration=".2s" data-delay=".4s">Grab a promo code for extra savings up to 75% on discounted hotels!</p>
//                         </div>
//                         {/* <!-- /.inner-content --> */}
//                     </div>
//                     {/* <!-- /.deal-bg --> */}
//                 </div>
//                 {/* <!-- /.col-md-6 --> */}
//                 <div className="col-lg-7">
//                     <div className="rt-section-title-wrapper text-white" data-animation="fadeIn" data-duration=".4s" >
//                         <h2 className="rt-section-title">
//                             <span>Take a Look at Our</span>
//                             Today's Top Deals
//                         </h2>
//                         {/* <!-- /.rt-section-title --> */}
//                         <p>Find great experiences, trips, and activities at fantastic prices around the globe.</p>
//                         <div className="section-title-spacer"></div>
//                         {/* <!-- /.section-title-spacer --> */}
//                         <div className="deal-bottom-content">
//                             <div className="rating-box">
//                                 <span className="d-block">EXCELLENT</span>
//                                 <span className="d-block"> <i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i>  of 205 Reviews</span>
//                                 <span className="d-block">Reviewed by Kim - Denmark</span>
//                             </div>
//                             {/* <!-- /.rating-box --> */}
//                             <div className="section-title-spacer"></div>
//                             {/* <!-- /.section-title-spacer --> */}
//                             <h4>Thailand Tours and Holidays 2018/2019</h4>
//                             <p>
//                                 Thailand is the perfect destination for those who love to spend time outdoors. You can soak up the
//                                 sunshine on the beautiful beaches of Phuket, or head to the North of the country to Chiang Mai for adventure and
//                                 outdoor
//                                 activities like water rafting and trekking. Of course, not to be missed is Bangkok, where you can tour its
//                                 floating
//                                 markets or lavish Grand Palace.
//                             </p>
//                             <div className="rt-button-group">
//                                 <a href="#" className="rt-btn rt-gradient rt-rounded rt-Bshadow-2">Read More</a>
//                                 <a href="#" className="rt-btn rt-outline-gradientL rt-rounded">Help Me Plan My Trip</a>
//                             </div>
//                         </div>
//                         {/* <!-- /.deal-bottom-content --> */}
//                     </div>
//                     {/* <!-- /.rt-section-title-wrapper --> */}
//                 </div>
//                 {/* <!-- /.col-md-6 --> */}
//             </div>
//             {/* <!-- /.row --> */}
//             <div className="row single-deal-carosel align-items-center">
//                 <div className="col-lg-5">
//                     <div className="deal-bg" style="background-image: url(assets/images/all-img/deal-bg.jpg)">
//                         <div className="inner-content">
//                             <h4 data-animation="fadeInDown" data-duration=".2s" data-delay=".4s">14 Day Classic Tour of Thailand & Beaches</h4>
//                             <p data-animation="fade-in-bottom" data-duration=".2s" data-delay=".4s">Grab a promo code for extra savings up to 75% on discounted hotels!</p>
//                         </div>
//                         {/* <!-- /.inner-content --> */}
//                     </div>
//                     {/* <!-- /.deal-bg --> */}
//                 </div>
//                 {/* <!-- /.col-md-6 --> */}
//                 <div className="col-lg-7">
//                     <div className="rt-section-title-wrapper text-white" data-animation="fadeIn" data-duration=".4s" >
//                         <h2 className="rt-section-title">
//                             <span>Take a Look at Our</span>
//                             Today's Top Deals
//                         </h2>
//                         {/* <!-- /.rt-section-title --> */}
//                         <p>Find great experiences, trips, and activities at fantastic prices around the globe.</p>
//                         <div className="section-title-spacer"></div>
//                         {/* <!-- /.section-title-spacer --> */}
//                         <div className="deal-bottom-content">
//                             <div className="rating-box">
//                                 <span className="d-block">EXCELLENT</span>
//                                 <span className="d-block"> <i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i>  of 205 Reviews</span>
//                                 <span className="d-block">Reviewed by Kim - Denmark</span>
//                             </div>
//                             {/* <!-- /.rating-box --> */}
//                             <div className="section-title-spacer"></div>
//                             {/* <!-- /.section-title-spacer --> */}
//                             <h4>Thailand Tours and Holidays 2018/2019</h4>
//                             <p>
//                                 Thailand is the perfect destination for those who love to spend time outdoors. You can soak up the
//                                 sunshine on the beautiful beaches of Phuket, or head to the North of the country to Chiang Mai for adventure and
//                                 outdoor
//                                 activities like water rafting and trekking. Of course, not to be missed is Bangkok, where you can tour its
//                                 floating
//                                 markets or lavish Grand Palace.
//                             </p>
//                             <div className="rt-button-group">
//                                 <a href="#" className="rt-btn rt-gradient rt-rounded rt-Bshadow-2">Read More</a>
//                                 <a href="#" className="rt-btn rt-outline-gradientL rt-rounded">Help Me Plan My Trip</a>
//                             </div>
//                         </div>
//                         {/* <!-- /.deal-bottom-content --> */}
//                     </div>
//                     {/* <!-- /.rt-section-title-wrapper --> */}
//                 </div>
//                 {/* <!-- /.col-md-6 --> */}
//             </div>
//             {/* <!-- /.row --> */}
//             <div className="row single-deal-carosel align-items-center">
//                 <div className="col-lg-5">
//                     <div className="deal-bg" style="background-image: url(assets/images/all-img/deal-bg.jpg)">
//                         <div className="inner-content">
//                             <h4 data-animation="fadeInDown" data-duration=".2s" data-delay=".4s">14 Day Classic Tour of Thailand & Beaches</h4>
//                             <p data-animation="fade-in-bottom" data-duration=".2s" data-delay=".4s">Grab a promo code for extra savings up to 75% on discounted hotels!</p>
//                         </div>
//                         {/* <!-- /.inner-content --> */}
//                     </div>
//                     {/* <!-- /.deal-bg --> */}
//                 </div>
//                 {/* <!-- /.col-md-6 --> */}
//                 <div className="col-lg-7">
//                     <div className="rt-section-title-wrapper text-white" data-animation="fadeIn" data-duration=".4s" >
//                         <h2 className="rt-section-title">
//                             <span>Take a Look at Our</span>
//                             Today's Top Deals
//                         </h2>
//                         {/* <!-- /.rt-section-title --> */}
//                         <p>Find great experiences, trips, and activities at fantastic prices around the globe.</p>
//                         <div className="section-title-spacer"></div>
//                         {/* <!-- /.section-title-spacer --> */}
//                         <div className="deal-bottom-content">
//                             <div className="rating-box">
//                                 <span className="d-block">EXCELLENT</span>
//                                 <span className="d-block"> <i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i><i className="fas fa-star"></i>  of 205 Reviews</span>
//                                 <span className="d-block">Reviewed by Kim - Denmark</span>
//                             </div>
//                             {/* <!-- /.rating-box --> */}
//                             <div className="section-title-spacer"></div>
//                             {/* <!-- /.section-title-spacer --> */}
//                             <h4>Thailand Tours and Holidays 2018/2019</h4>
//                             <p>
//                                 Thailand is the perfect destination for those who love to spend time outdoors. You can soak up the
//                                 sunshine on the beautiful beaches of Phuket, or head to the North of the country to Chiang Mai for adventure and
//                                 outdoor
//                                 activities like water rafting and trekking. Of course, not to be missed is Bangkok, where you can tour its
//                                 floating
//                                 markets or lavish Grand Palace.
//                             </p>
//                             <div className="rt-button-group">
//                                 <a href="#" className="rt-btn rt-gradient rt-rounded rt-Bshadow-2">Read More</a>
//                                 <a href="#" className="rt-btn rt-outline-gradientL rt-rounded">Help Me Plan My Trip</a>
//                             </div>
//                         </div>
//                         {/* <!-- /.deal-bottom-content --> */}
//                     </div>
//                     {/* <!-- /.rt-section-title-wrapper --> */}
//                 </div>
//                 {/* <!-- /.col-md-6 --> */}
//             </div>
//             {/* <!-- /.row --> */}
//        </div>
//        {/* <!-- /.deal-carosel-active --> */}
//     </div>
//     {/* <!-- /.container --> */}
//  </section>
// {/* <!--     ========works start========== --> */}
// <div className="spacer-top"></div>
// {/* <!-- /.spacer-top --> */}
//  <section className="works-area">
//     <div className="container">
//         <div className="row">
//             <div className="col-xl-10 text-center mx-auto text-center">
//                 <div className="rt-section-title-wrapper">
//                     <h2 className="rt-section-title">
//                         <span>Here's How It Works</span>
//                         Getting Started? It’s Simple
//                     </h2>
//                     {/* <!-- /.rt-section-title --> */}
//                     <p>Prepare For Your Trip.Find out all you need to know before you go.Traveling is as unique as you are. And there is no one
//                     package that fits all. That's why we offer customized travel packages.</p>
//                 </div>
//                 {/* <!-- /.rt-section-title-wrapper- --> */}
//             </div>
//             {/* <!-- /.col-lg-12 --> */}
//         </div>
//         {/* <!-- /.row --> */}
//         <div className="section-title-spacer"></div>
//         {/* <!-- /.section-title-spacer --> */}
//         <div className="row">
//             <div className="col-lg-3 col-md-6 mx-auto text-center">
//                 <div className="services-box-2 wow fade-in-bottom">
//                     <div className="services-thumb">
//                         <img src="assets/images/service-icons/s_icon_4.png" alt="service-icons" draggable="false"/>
//                     </div>
//                     {/* <!-- /.services-thumb --> */}
//                     <span className="inner-counter"></span>
//                     <h4>Search</h4>
//                     <p>Over 1000 + 
// 					Appoinments</p>
//                 </div>
//                 {/* <!-- /.services-box-2 --> */}
//             </div>
//             {/* <!-- /.col-lg-3 --> */}
//             <div className="col-lg-3 col-md-6 mx-auto text-center">
//                 <div className="services-box-2 wow fade-in-bottom" data-wow-duration="1s">
//                     <div className="services-thumb">
//                         <img src="assets/images/service-icons/s_icon_5.png" alt="service-icons" draggable="false"/>
//                     </div>
//                     {/* <!-- /.services-thumb --> */}
//                     <span className="inner-counter"></span>
//                     <h4>Compare & Book</h4>
//                     <p>By price, location, rating
//                         and more.</p>
//                 </div>
//                 {/* <!-- /.services-box-2 --> */}
//             </div>
//             {/* <!-- /.col-lg-3 --> */}
//             <div className="col-lg-3 col-md-6 mx-auto text-center">
//                 <div className="services-box-2 wow fade-in-bottom" data-wow-duration="1.5s">
//                     <div className="services-thumb">
//                         <img src="assets/images/service-icons/s_icon_6.png" alt="service-icons" draggable="false"/>
//                     </div>
//                     {/* <!-- /.services-thumb --> */}
//                     <span className="inner-counter"></span>
//                     <h4>Get a OTP</h4>
//                     <p>For Verification Get OTP From vendor</p>
//                 </div>
//                 {/* <!-- /.services-box-2 --> */}
//             </div>
//             {/* <!-- /.col-lg-3 --> */}
//             <div className="col-lg-3 col-md-6 mx-auto text-center">
//                 <div className="services-box-2 wow fade-in-bottom" data-wow-duration="2s">
//                     <div className="services-thumb">
//                         <img src="assets/images/service-icons/s_icon_7.png" alt="service-icons" draggable="false"/>
//                     </div> 
//                     {/* <!-- /.services-thumb --> */}
//                     <span className="inner-counter"></span>
//                     <h4>Book the best vendor!</h4>
//                     <p>By finding the best service for
//                         your celebration.</p>
//                 </div>
//                 {/* <!-- /.services-box-2 --> */}
//             </div>
//             {/* <!-- /.col-lg-3 --> */}
           
//         </div>
//         {/* <!-- /.row --> */}
//     </div>
//     {/* <!-- /.container --> */}
//  </section>
// {/* <!--     ============ Portfolio Start=============== --> */}
// <div className="spacer-top"></div>
// {/* <!-- /.spacer-top --> */}
// <section className="portfolio-area rt-section-padding rtbgprefix-full bg-hide-md gradinet-bg-md" style="background-image: url(assets/images/backgrounds/portfoliobg.png)">
//         <div className="row">
//             <div className="col-xl-8 text-center mx-auto text-center">
//                 <div className="rt-section-title-wrapper text-white">
//                     <h2 className="rt-section-title">
//                         <span>Take a Look at Our</span>
//                         Recommended Services
//                     </h2>
//                     {/* <!-- /.rt-section-title --> */}
//                     <p>We have made a list of suggested activities based on your interests.Browse through our most popular
//                     Services! Our Featured search can help you find the trip that's perfect for you!.</p>
//                 </div>
//                 {/* <!-- /.rt-section-title-wrapper- --> */}
//             </div>
//             {/* <!-- /.col-lg-12 --> */}
//         </div>
//         {/* <!-- /.row --> */}
//         <div className="section-title-spacer"></div>
//         {/* <!-- /.section-title-spacer --> */}
//         <div className="container">
// 		<div className="row">
//             <div className="col-12">
//                 <ul className="filter-list">
// 				<div id="carouselContent" className="carousel slide" data-ride="carousel">
//         <div className="carousel-inner" role="listbox">
//             <div className="carousel-item active text-center p-4">
//                  <li data-filter="*" className="active ">All Category</li>
//                     <li data-filter=".cat-1">Apparel Rent</li>
//                     <li data-filter=".cat-2">Venue</li>
//                     <li data-filter=".cat-3">Music / Entertainment</li>
//                     <li data-filter=".cat-4">Catering</li>
//                     <li data-filter=".cat-5">Beauty Services</li>
//                     <li data-filter=".cat-6">Travel Services</li>
//             </div>
//             <div className="carousel-item text-center p-4">
                
//                	<li data-filter=".cat-1">Photography</li>
//                     <li data-filter=".cat-7">Decorators</li>
//                     <li data-filter=".cat-8">Vehicle Rentals</li>
//                     <li data-filter=".cat-9">Honeymoon Packages</li>
//                     <li data-filter=".cat-10">Invitation</li>
//                     <li data-filter=".cat-11">Jewellery</li>
// 					<li data-filter=".cat-12">Apparel Shopping</li>
//             </div>
//         </div>
//         <a className="carousel-control-prev" href="#carouselContent" role="button" data-slide="prev">
//             <span className="carousel-control-prev-icon" aria-hidden="true"></span>
//             <span className="sr-only">Previous</span>
//         </a>
//         <a className="carousel-control-next" href="#carouselContent" role="button" data-slide="next">
//             <span className="carousel-control-next-icon" aria-hidden="true"></span>
//             <span className="sr-only">Next</span>
//         </a>
//     </div>
                  
				
//                 </ul>
//             </div>
//             {/* <!-- /.col-12 --> */}
//         </div>
//         {/* <!-- /.row --> */}
		 
//         <div className="row grid">
//             <div className="col-lg-4 col-md-6 grid-item cat-1">
//                 <div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-1.jpg)">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
//             </div>
//             {/* <!-- /.col-md-4 --> */}
//             <div className="col-lg-4 col-md-6 grid-item cat-2">
//                <a href="category.html">
// 			   <div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-2.jpg)" data-wow-duration="1s">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
// 				</a>
//             </div>
//             {/* <!-- /.col-md-4 --> */}
//             <div className="col-lg-4 col-md-6 grid-item cat-3">
// 			 <a href="category.html">
//                 <div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-3.jpg)" data-wow-duration="1.3s">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
// 				</a>
//             </div>
//             {/* <!-- /.col-md-4 --> */}
//             <div className="col-lg-4 col-md-6 grid-item cat-4">
//                 <a href="category.html">
// 			   <div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-4.jpg)" data-wow-duration="1.6s">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
// 				</a>
//             </div>
//             {/* <!-- /.col-md-4 --> */}
//             <div className="col-lg-4 col-md-6 grid-item cat-5">
//                  <a href="category.html">
// 				<div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-5.jpg)" data-wow-duration="1.9s">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
// 				</a>
//             </div>
//             {/* <!-- /.col-md-4 --> */}
//             <div className="col-lg-4 col-md-6 grid-item cat-6">
//                  <a href="category.html">
// 				<div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-6.jpg)" data-wow-duration="2.2s">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
// 				</a>
//             </div>
//             {/* <!-- /.col-md-4 --> */}
// 			 <div className="col-lg-4 col-md-6 grid-item cat-7">
//                  <a href="category.html">
// 				<div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-6.jpg)" data-wow-duration="2.2s">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
// 				</a>
//             </div>
//             {/* <!-- /.col-md-4 --> */}
// 			 <div className="col-lg-4 col-md-6 grid-item cat-8">
//                  <a href="category.html">
// 				<div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-6.jpg)" data-wow-duration="2.2s">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
// 				</a>
//             </div>
//             {/* <!-- /.col-md-4 --> */}
// 			 <div className="col-lg-4 col-md-6 grid-item cat-9">
//                  <a href="category.html">
// 				<div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-6.jpg)" data-wow-duration="2.2s">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
// 				</a>
//             </div>
//             {/* <!-- /.col-md-4 --> */}
// 			 <div className="col-lg-4 col-md-6 grid-item cat-10">
//                  <a href="category.html">
// 				<div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-6.jpg)" data-wow-duration="2.2s">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
// 				</a>
//             </div>
//             {/* <!-- /.col-md-4 --> */}
// 			 <div className="col-lg-4 col-md-6 grid-item cat-11">
//                  <a href="category.html">
// 				<div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-6.jpg)" data-wow-duration="2.2s">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
// 				</a>
//             </div>
//             {/* <!-- /.col-md-4 --> */}
// 			 <div className="col-lg-4 col-md-6 grid-item cat-12">
//                  <a href="category.html">
// 				<div className="portfolio-box-1 wow fade-in-bottom " style="background-image: url(assets/images/portfolio/port-6.jpg)" data-wow-duration="2.2s">
//                     <div className="rt-overlay"></div>
//                     {/* <!-- /.rt-overlay --> */}
//                     <div className="portfolio-badge">
//                         <span>From</span>
//                         <span><sup>Rs.</sup>239</span>
//                     </div>
//                     {/* <!-- /.portfolio-badge --> */}
//                     <div className="inner-content text-white">
//                         <h6>The Millenium Hilton New York</h6>
//                         <p> <span>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                                 <i className="fas fa-star"></i>
//                             </span>
//                             <span>4.5 / 5 (473 reviews)</span>
//                         </p>
//                     </div>
//                     {/* <!-- /.inner-content --> */}
//                 </div>
//                 {/* <!-- /.portfolio-box-1 --> */}
// 				</a>
//             </div>
//             {/* <!-- /.col-md-4 --> */}
			
//         </div>
//         {/* <!-- /.row --> */}
//         <div className="row">
//             <div className="col-12 text-center mt-4">
//                 <a href="category.html" className="rt-btn rt-gradient text-uppercase rt-sm rt-rounded rt-Bshadow-1">browse more</a>
//                 {/* <!-- /.rt-btn --> */}
//             </div>
//             {/* <!-- /.col-12 --> */}
//         </div>
//         {/* <!-- /.row --> */}
//     </div>
//     {/* <!-- /.container --> */}
// </section>

// {/* <!-- ======== Flight deals start====== --> */}

// <div className="spacer-top"></div>
// {/* <!-- /.spacer-top --> */}



// {/* <!--     ====== call to action====== --> */}



// {/* <!--     =======app area strat========= --> */}

// <div className="spacer-top"></div>
// {/* <!-- /.spacer-top --> */}


// <section className="app-area rtbgprefix-cover" style="background-image: url(assets/images/backgrounds/app_bg.png)"
//     data-scrollax-parent="true">
//     <div className="rt-shape-elements-1 rtbgprefix-contain"
//         style="background-image: url(assets/images/shape-elements/shape-3.png)"
//         data-scrollax="properties: { translateY: '50px' }"></div>
//         {/* <!-- /.rt-shape-elements-1 --> */}
//     <div className="container">
//         <div className="row align-items-center">
//             <div className="col-lg-5 text-center text-lg-left">
//                 <img src="assets/images/all-img/app-mbl.png" alt="mockup image" draggable="false" 
//                  className="wow fade-in-left" data-wow-duration="1s" data-wow-delay="0.2s"/>
//             </div>
//             {/* <!-- /.col-lg-5 --> */}
//             <div className="col-lg-7">
//                 <div className="rt-section-title-wrapper">
//                     <div className="wow fade-in-bottom" data-wow-duration="1s" data-wow-delay="0.6s">
//                         <h2 className="rt-section-title">
//                             <span>All Category In One App</span>
//                             Download App
//                         </h2>
//                         {/* <!-- /.rt-section-title --> */}
//                         <p>
//                             All your plans, in single App. You handle the booking.Access services, reservations, maps, and
//                             more on your favorite device! View trending destinations. Discover popular plans. Listen to
//                             your heart. Find or create your perfect Occasion.
//                             Experience different cultures. Create unforgettable memories.Keep up-to-date with
//                             active, view your favourites, visit previous adventures. Managing a service has never
//                             been easier.
                        
//                         </p>
//                         <br/>
//                         <p>
//                             Download the Namma Carnival app and join our ever-growing community of passionate
//                             Team. Find lasting services, create unforgettable
//                             memories.
//                         </p>
//                     </div>
//                     {/* <!-- /.wow --> */}
//                     <div className="rt-button-group mt-5 wow fade-in-bottom" data-wow-duration="1s" data-wow-delay="0.9s">
//                         <a href="#" className="rt-btn rt-app-parimary rt-rounded">
//                             <div className="app-thumb">
//                                 <i className="fab fa-google-play"></i>
//                             </div>
//                             {/* <!-- /.app-thumb --> */}
//                             <div className="app-text">
//                                 <span>GET IT ON</span>
//                                 <span>Appstore</span>
//                             </div>
//                             {/* <!-- /.app-text --> */}
//                         </a>
//                         <a href="#" className="rt-btn rt-app-secondary rt-rounded">
//                             <div className="app-thumb">
//                                 <i className="fab fa-apple"></i>
//                             </div>
//                             {/* <!-- /.app-thumb --> */}
//                             <div className="app-text">
//                                 <span>GET IT ON</span>
//                                 <span>Appstore</span>
//                             </div>
//                             {/* <!-- /.app-text --> */}
//                         </a>
//                     </div>
//                     {/* <!-- /.rt-button-group --> */}
//                 </div>
//                 {/* <!-- /.rt-section-title-wrapper --> */}
//             </div>
//             {/* <!-- /.col-lg-7 --> */}
//         </div>
//         {/* <!-- /.row --> */}
//     </div>
//     {/* <!-- /.container --> */}
// </section>

// {/* <!--   ============= video area start========== --> */}


// {/* <!--     ============= Testimonilas area start========== --> */}
// <section className="testimonials-area" data-scrollax-parent="true">
//     <div className="rt-shape-emenetns-1" style="background-image: url(assets/images/shape-elements/shape-4.png)"
//         data-scrollax="properties: { translateY: '-140px' }"></div>
//         {/* <!-- /.rt-shape-emenetns-1 --> */}
//     <div className="container">
//         <div className="row">
//             <div className="col-xl-9 mx-auto text-center">
//                 <div className="rt-section-title-wrapper">
//                     <h2 className="rt-section-title">
//                         <span>testimonials</span>
//                         What Our Customers Say
//                     </h2>
//                     {/* <!-- /.rt-section-title --> */}
//                     <p>
//                         We have many happy customers that have booked holidays with us.Some Impresions from our
//                         Customers! Please read some of the lovely things our Customers say about us.
//                     </p>
//                 </div>
//                 {/* <!-- /.rt-section-title-wrapper --> */}
//             </div>
//             {/* <!-- /.col-lg-9 --> */}
//         </div>
//         {/* <!-- /.row --> */}
//         <div className="section-title-spacer"></div>
//         {/* <!-- /.section-title-spacer --> */}
//         <div className="row">
//             <div className="col-lg-12 mx-auto">
//                 <div className="testimoninal-active-1">
//     <div className="singleTbox-1 text-center active position-1" data-position="position-1">
//         <div className="testi-thumb">
//             <div className="inner-bg" style="background-image: url(assets/images/testimonials/t_1.png)"></div>
//             {/* <!-- /.inner-bg --> */}
//             <span className="social-badge"><i className="fab fa-linkedin-in    "></i></span>
//         </div>
//         {/* <!-- /.testi-thumb --> */}
//         <div className="autor-bio">
//             <h5>Oliver Wolfe</h5>
//             <p>United Kingdom,15th December, 2018</p>
//             <span className="rating">
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//             </span>
//         </div>
//         {/* <!-- /.autor-bio --> */}
//         <div className="inner-content">
//             <p>
//                 Memorable holidays planned an amazing trip for us to Italy. The trip had a mix of all activities that we
//                 were interested
//                 in. The hotels were nice and situated very close to the station. This made travelling in the city very
//                 easy. The tours
//                 planned were also very good with very nice guides. We would definitely recommend a trip with them.
//             </p>
//         </div>
//         {/* <!-- /.inner-content --> */}
//     </div>
//     {/* <!-- /.singleTbox-1 --> */}
//     <div className="singleTbox-1 text-center inactive position-2" data-position="position-2">
//         <div className="testi-thumb">
//             <div className="inner-bg" style="background-image: url(assets/images/testimonials/t_2.png)"></div>
//             {/* <!-- /.inner-bg --> */}
//             <span className="social-badge"><i className="fab fa-linkedin-in    "></i></span>
//         </div>
//         {/* <!-- /.testi-thumb --> */}
//         <div className="autor-bio">
//             <h5>Oliver Wolfe</h5>
//             <p>United Kingdom,15th December, 2018</p>
//             <span className="rating">
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//             </span>
//         </div>
//         {/* <!-- /.autor-bio --> */}
//         <div className="inner-content">
//             <p>
//                 Memorable holidays planned an amazing trip for us to Italy. The trip had a mix of all activities that we
//                 were interested
//                 in. The hotels were nice and situated very close to the station. This made travelling in the city very
//                 easy. The tours
//                 planned were also very good with very nice guides. We would definitely recommend a trip with them.
//             </p>
//         </div>
//         {/* <!-- /.inner-content --> */}
//     </div>
//     {/* <!-- /.singleTbox-1 --> */}
//     <div className="singleTbox-1 text-center inactive position-3" data-position="position-3">
//         <div className="testi-thumb">
//             <div className="inner-bg" style="background-image: url(assets/images/testimonials/t_3.png)"></div>
//             {/* <!-- /.inner-bg --> */}
//             <span className="social-badge"><i className="fab fa-linkedin-in    "></i></span>
//         </div>
//         {/* <!-- /.testi-thumb --> */}
//         <div className="autor-bio">
//             <h5>Oliver Wolfe</h5>
//             <p>United Kingdom,15th December, 2018</p>
//             <span className="rating">
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//             </span>
//         </div>
//         {/* <!-- /.autor-bio --> */}
//         <div className="inner-content">
//             <p>
//                 Memorable holidays planned an amazing trip for us to Italy. The trip had a mix of all activities that we
//                 were interested
//                 in. The hotels were nice and situated very close to the station. This made travelling in the city very
//                 easy. The tours
//                 planned were also very good with very nice guides. We would definitely recommend a trip with them.
//             </p>
//         </div>
//         {/* <!-- /.inner-content --> */}
//     </div>
//     {/* <!-- /.singleTbox-1 --> */}
//     <div className="singleTbox-1 text-center inactive position-4" data-position="position-4">
//         <div className="testi-thumb">
//             <div className="inner-bg" style="background-image: url(assets/images/testimonials/t_4.png)"></div>
//             {/* <!-- /.inner-bg --> */}
//             <span className="social-badge"><i className="fab fa-linkedin-in    "></i></span>
//         </div>
//         {/* <!-- /.testi-thumb --> */}
//         <div className="autor-bio">
//             <h5>Oliver Wolfe</h5>
//             <p>United Kingdom,15th December, 2018</p>
//             <span className="rating">
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//             </span>
//         </div>
//         {/* <!-- /.autor-bio --> */}
//         <div className="inner-content">
//             <p>
//                 Memorable holidays planned an amazing trip for us to Italy. The trip had a mix of all activities that we
//                 were interested
//                 in. The hotels were nice and situated very close to the station. This made travelling in the city very
//                 easy. The tours
//                 planned were also very good with very nice guides. We would definitely recommend a trip with them.
//             </p>
//         </div>
//         {/* <!-- /.inner-content --> */}
//     </div>
//     {/* <!-- /.singleTbox-1 --> */}
//     <div className="singleTbox-1 text-center inactive position-5" data-position="position-5">
//         <div className="testi-thumb">
//             <div className="inner-bg" style="background-image: url(assets/images/testimonials/t_5.png)"></div>
//             {/* <!-- /.inner-bg --> */}
//             <span className="social-badge"><i className="fab fa-linkedin-in "></i></span>
//         </div>
//         {/* <!-- /.testi-thumb --> */}
//         <div className="autor-bio">
//             <h5>Oliver Wolfe</h5>
//             <p>United Kingdom,15th December, 2018</p>
//             <span className="rating">
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//             </span>
//         </div>
//         {/* <!-- /.autor-bio --> */}
//         <div className="inner-content">
//             <p>
//                 Memorable holidays planned an amazing trip for us to Italy. The trip had a mix of all activities that we
//                 were interested
//                 in. The hotels were nice and situated very close to the station. This made travelling in the city very
//                 easy. The tours
//                 planned were also very good with very nice guides. We would definitely recommend a trip with them.
//             </p>
//         </div>
//         {/* <!-- /.inner-content --> */}
//     </div>
//     {/* <!-- /.singleTbox-1 --> */}
//     <div className="singleTbox-1 text-center inactive position-6" data-position="position-6">
//         <div className="testi-thumb">
//             <div className="inner-bg" style="background-image: url(assets/images/testimonials/t_6.png)"></div>
//             {/* <!-- /.inner-bg --> */}
//             <span className="social-badge"><i className="fab fa-linkedin-in    "></i></span>
//         </div>
//         {/* <!-- /.testi-thumb --> */}
//         <div className="autor-bio">
//             <h5>Oliver Wolfe</h5>
//             <p>United Kingdom,15th December, 2018</p>
//             <span className="rating">
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//             </span>
//         </div>
//         {/* <!-- /.autor-bio --> */}
//         <div className="inner-content">
//             <p>
//                 Memorable holidays planned an amazing trip for us to Italy. The trip had a mix of all activities that we
//                 were interested
//                 in. The hotels were nice and situated very close to the station. This made travelling in the city very
//                 easy. The tours
//                 planned were also very good with very nice guides. We would definitely recommend a trip with them.
//             </p>
//         </div>
//         {/* <!-- /.inner-content --> */}
//     </div>
//     {/* <!-- /.singleTbox-1 --> */}
//     <div className="singleTbox-1 text-center inactive position-7" data-position="position-7">
//         <div className="testi-thumb">
//             <div className="inner-bg" style="background-image: url(assets/images/testimonials/t_7.png)"></div>
//             {/* <!-- /.inner-bg --> */}
//             <span className="social-badge"><i className="fab fa-linkedin-in    "></i></span>
//         </div>
//         {/* <!-- /.testi-thumb --> */}
//         <div className="autor-bio">
//             <h5>Oliver Wolfe</h5>
//             <p>United Kingdom,15th December, 2018</p>
//             <span className="rating">
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//             </span>
//         </div>
//         {/* <!-- /.autor-bio --> */}
//         <div className="inner-content">
//             <p>
//                 Memorable holidays planned an amazing trip for us to Italy. The trip had a mix of all activities that we
//                 were interested
//                 in. The hotels were nice and situated very close to the station. This made travelling in the city very
//                 easy. The tours
//                 planned were also very good with very nice guides. We would definitely recommend a trip with them.
//             </p>
//         </div>
//         {/* <!-- /.inner-content --> */}
//     </div>
//     {/* <!-- /.singleTbox-1 --> */}
//     <div className="singleTbox-1 text-center inactive position-8" data-position="position-8">
//         <div className="testi-thumb">
//             <div className="inner-bg" style="background-image: url(assets/images/testimonials/t_8.png)"></div>
//             {/* <!-- /.inner-bg --> */}
//             <span className="social-badge"><i className="fab fa-linkedin-in    "></i></span>
//         </div>
//         {/* <!-- /.testi-thumb --> */}
//         <div className="autor-bio">
//             <h5>Oliver Wolfe</h5>
//             <p>United Kingdom,15th December, 2018</p>
//             <span className="rating">
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//             </span>
//         </div>
//         {/* <!-- /.autor-bio --> */}
//         <div className="inner-content">
//             <p>
//                 Memorable holidays planned an amazing trip for us to Italy. The trip had a mix of all activities that we
//                 were interested
//                 in. The hotels were nice and situated very close to the station. This made travelling in the city very
//                 easy. The tours
//                 planned were also very good with very nice guides. We would definitely recommend a trip with them.
//             </p>
//         </div>
//         {/* <!-- /.inner-content --> */}
//     </div>
//     {/* <!-- /.singleTbox-1 --> */}
//     <div className="singleTbox-1 text-center inactive position-9" data-position="position-9">
//         <div className="testi-thumb">
//             <div className="inner-bg" style="background-image: url(assets/images/testimonials/t_9.png)"></div>
//             {/* <!-- /.inner-bg --> */}
//             <span className="social-badge"><i className="fab fa-linkedin-in    "></i></span>
//         </div>
//         {/* <!-- /.testi-thumb --> */}
//         <div className="autor-bio">
//             <h5>Oliver Wolfe</h5>
//             <p>United Kingdom,15th December, 2018</p>
//             <span className="rating">
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//             </span>
//         </div>
//         {/* <!-- /.autor-bio --> */}
//         <div className="inner-content">
//             <p>
//                 Memorable holidays planned an amazing trip for us to Italy. The trip had a mix of all activities that we
//                 were interested
//                 in. The hotels were nice and situated very close to the station. This made travelling in the city very
//                 easy. The tours
//                 planned were also very good with very nice guides. We would definitely recommend a trip with them.
//             </p>
//         </div>
//         {/* <!-- /.inner-content --> */}
//     </div>
//     {/* <!-- /.singleTbox-1 --> */}
//     <div className="singleTbox-1 text-center inactive position-10" data-position="position-10">
//         <div className="testi-thumb">
//             <div className="inner-bg" style="background-image: url(assets/images/testimonials/t_10.png)"></div>
//             {/* <!-- /.inner-bg --> */}
//             <span className="social-badge"><i className="fab fa-linkedin-in    "></i></span>
//         </div>
//         {/* <!-- /.testi-thumb --> */}
//         <div className="autor-bio">
//             <h5>Oliver Wolfe</h5>
//             <p>United Kingdom,15th December, 2018</p>
//             <span className="rating">
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//                 <i className="fas fa-star"></i>
//             </span>
//         </div>
//         {/* <!-- /.autor-bio --> */}
//         <div className="inner-content">
//             <p>
//                 Memorable holidays planned an amazing trip for us to Italy. The trip had a mix of all activities that we
//                 were interested
//                 in. The hotels were nice and situated very close to the station. This made travelling in the city very
//                 easy. The tours
//                 planned were also very good with very nice guides. We would definitely recommend a trip with them.
//             </p>
//         </div>
//         {/* <!-- /.inner-content --> */}
//     </div>
//     {/* <!-- /.singleTbox-1 --> */}
// </div>
// {/* <!-- /.testimoninal-active-1 --> */}
//             </div>
//             {/* <!-- /.col-lg-7 --> */}
//         </div>
//         {/* <!-- /.row --> */}
//         <div className="rt-divider style-one rt-margin-top"></div>
//         {/* <!-- /.divider --> */}
//     </div>
//     {/* <!-- /.containe --> */}
// </section>


// {/* <!--   ============= Brands area start========== --> */}


// <div className="spacer-top"></div>
// {/* <!-- /.spacer-top --> */}
// <section className="brands-area">
//     <div className="container">
//         <div className="row">
//             <div className="col-lg-9 mx-auto text-center">
//                 <div className="rt-section-title-wrapper">
//                     <h2 className="rt-section-title">
//                         <span>Take a Look at Our</span>
//                         Trusted Partners
//                     </h2>
//                     {/* <!-- /.rt-section-title --> */}
//                     <p>
//                         We are committed to being the best partner. Namma Carnival believes in being your trusted partner and
//                         earning that trust through
//                         confidence and performance in service and support.
//                     </p>
//                 </div>
//                 {/* <!-- /.rt-section-title-wrapper --> */}
//             </div>
//             {/* <!-- /.col-lg-9 --> */}
//         </div>
//         {/* <!-- /.row --> */}
//         <div className="section-title-spacer"></div>
//         {/* <!-- /.section-title-spacer --> */}
//         <div className="row">
//             <div className="col-lg-12 mx-auto">
//                 <ul className="rt-border-brands"/>
//     <li className="single-border-brands">
//         <a href="#" className="wow flipInX d-block">
//             <img src="assets/images/brands/brands-1.png" alt="brands image" draggable="false"/>
//         </a>
//     </li>
//     {/* <!-- /.single-border-brands --> */}
//     <li className="single-border-brands">
//         <a href="#" className="wow flipInX d-block" data-wow-duration="1s">
//             <img src="assets/images/brands/brands-2.png" alt="brands image" draggable="false"/>
//         </a>
//     </li>
//     {/* <!-- /.single-border-brands --> */}
//     <li className="single-border-brands">
//         <a href="#" className="wow flipInX d-block" data-wow-duration="1.5s">
//             <img src="assets/images/brands/brands-3.png" alt="brands image" draggable="false"/>
//         </a>
//     </li>
//     {/* <!-- /.single-border-brands --> */}
//     <li className="single-border-brands">
//         <a href="#" className="wow flipInX d-block" data-wow-duration="2s"> 
//             <img src="assets/images/brands/brands-4.png" alt="brands image" draggable="false"/>
//         </a>
//     </li>
//     {/* <!-- /.single-border-brands --> */}
//     <li className="single-border-brands">
//         <a href="#" className="wow flipInX d-block" data-wow-duration="2.5s">
//             <img src="assets/images/brands/brands-5.png" alt="brands image" draggable="false"/>
//         </a>
//     </li>
//     {/* <!-- /.single-border-brands --> */}
//     <li className="single-border-brands">
//         <a href="#" className="wow flipInX d-block" data-wow-duration="3s">
//             <img src="assets/images/brands/brands-6.png" alt="brands image" draggable="false"/>
//         </a>
//     </li>
    
//             </div>
//         </div>
//     </div>
// </section>
<></>
    );
}
export default NavBar;