import { React,Component } from "react";

class Header extends Component {
    constructor(){
        super();
        this.state = {
          displayResponse:'',
          loginAuth:'',
            showHide : false,
            showOTPModal:false,
            loginStatus: false,
                      name:"",
                      phone:"",
                      email:"",
                      location:"",
                      password:"",
                      confirmpassword:""
        }
        this.updateInputValue = this.updateInputValue.bind(this);
        this.handleRegistrationData = this.handleRegistrationData.bind(this);
        this.handleLoginStatus = this.handleLoginStatus.bind(this);
    }
    updateInputValue(evt,column) {
        switch (column) {
          case "name":
            this.setState({ name: evt.target.value })
            break;
          case "phone":
            this.setState({ phone: evt.target.value })
            break;   
          case "email":
            this.setState({ email: evt.target.value })
            break;    
          case "location":
            this.setState({ location: evt.target.value })
            break;      
          case "password":
            this.setState({ password: evt.target.value })
            break;        
          case "confirmpassword":
            this.setState({ confirmpassword: evt.target.value })
              break;
          case "otp":
            this.setState({ otp: evt.target.value })
              break;         
          default:
            break;
        }
        // this.setState({ column: evt.target.value })
        // console.log(this.state)
    }
    handleModalShowHide() {
        this.setState({ showHide: !this.state.showHide })
    }
    handleLoginStatus() {
       this.setState({ loginStatus: !this.state.loginStatus })
    }
    
    handleLogoutRequest() {
      sessionStorage.removeItem('key');
      sessionStorage.clear();
      this.setState({ loginStatus: !this.state.loginStatus })
    }

    // handleRegistrationData() {
    //   var OTPRegistration = {
    //     phone:this.state.phone,
    //     otp:this.state.otp,
    //   }
    //     console.log("OTPRegistration",OTPRegistration)
    // }

    handleLoginRequest() {
      const payload = {
        email:this.state.email,
        password:this.state.password,
        type:"login"
        }
      fetch('http://localhost:5000/api/users/login/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            }).then(res => {
                res.json().then(data => {

                  window.sessionStorage.setItem("key", data);

                  // window.sessionStorage.getItem("key");
                  const loginAuth = window.sessionStorage.getItem("key");

                  console.log("data-->>>>",payload,data)

                    this.setState({
                      // showOTPModal:!this.state.showOTPModal,
                      showHide : !this.state.showHide,
                      loginAuth : window.sessionStorage.getItem("key")
                    })
                    // .then(() => {
                    //   this.setState({
                    //     // showOTPModal:!this.state.showOTPModal,
                    //     showHide : !this.state.showHide,
                    //     loginAuth : window.sessionStorage.getItem("key")
                    //   })
                    // })
               })
            });
        }
        sendotp() {
          // this.handleModalShowHide();
          console.log(this.props.data)
          // if(this.props.value.type=="register") {
            const payload = {
              // "name":this.state.name,
              // "email":this.state.email,
              "phone":this.state.phone,
              // "password":this.state.password,
              // "confirm_password":this.state.confirmpassword,
              "type":"register"
              // "opt":this.state.otp
              };
              // data.append("myjsonkey", JSON.stringify(payload));
              fetch('http://localhost:5000/api/users/sendotp/', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(payload)
              }).then(res => {
                
                res.json().then(data => {
                  console.log(data.msg);
                  if(data.msg== "OTP Sent."){
                    this.setState({
                      showOTPModal:true,
                      showHide : this.state.showHide
                      })
                    }
                });
              });
          }
      
        verifyotp() {
          this.handleModalShowHide();
            const payload = {
               // "name":this.state.name,
              // "email":this.state.email,
              "phone":this.state.phone,
              // "password":this.state.password,
              // "confirm_password":this.state.confirmpassword,
              // "type":"register"
              "opt":this.state.otp
              };
              // data.append("myjsonkey", JSON.stringify(payload));
              fetch('http://localhost:5000/api/users/verifyotp/', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(payload)
              }).then(res => {
                res.json().then(data => {
                  console.log(data.msg);
                  if(data.otpVerification==true){
                      alert("OTP Verified");
                    this.setState({
                          // showOTPModal:!this.state.showOTPModal,
                          showHide : this.state.showHide
                      })
                    }
                  else {
                    alert("OTP NOT Verified");
                      this.setState({
                            showOTPModal:!this.state.showOTPModal,
                            showHide : !this.state.showHide
                        })
                      }
                });
            });
        }
    handleRegistrationData() {
      var OTPRegistration = {
        phone:this.state.phone,
        otp:this.state.otp,
      }
      const registerData = {
        name:this.state.name,
        phone:this.state.phone,
        email:this.state.email,
        location:this.state.location,
        password:this.state.password,
        confirmpassword:this.state.confirmpassword,
        type:"register"
        }
        const data = {
              "name":this.state.name,
              "email":this.state.email,
              "phone":this.state.phone,
              "password":this.state.password,
              "confirm_password":this.state.confirmpassword
      }
      
        const requestOptions = {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ 
            "name":this.state.name,
            "email":this.state.email,
            "phone":this.state.phone,
            "password":this.state.password,
            "confirm_password":this.state.confirmpassword
            })
        };
            const payload = {
            "name":this.state.name,
            "email":this.state.email,
            "phone":this.state.phone,
            "password":this.state.password,
            "confirm_password":this.state.confirmpassword
            };

            fetch('http://localhost:5000/api/users/register/', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            }).then(res => {
                res.json().then(data => {
                   console.log("data-->>>>",data.msg)
                  this.setState({
                      // displayResponse:data,
                      // showOTPModal:!this.state.showOTPModal,
                      // showHide : !this.state.showHide,
                       payload : {
                        "name":this.state.name,
                        "email":this.state.email,
                        "phone":this.state.phone,
                        "password":this.state.password,
                        "confirm_password":this.state.confirmpassword,
                        "verified":false
                        },
                  })
                  if(!data.msg.verified){
                    this.setState({
                      showOTPModal:!this.state.showOTPModal,
                      showHide : !this.state.showHide,
                    });
                  }
                  this.sendotp();
               })
            });
        }

    render() {
    const right = "right";
    const center = "center";
    const mystyle = {
        padding:"10px 15px",
        margin:"10px",
        marginLeft:"35%"
      };
      return (
        <>
        <header className="rt-site-header  rt-fixed-top white-menu">
            <div className="main-header rt-sticky">
                <nav className="navbar">
                    <div className="container1 container">
                        <a href="index.html" className="brand-logo"><img src="assets/images/logo/logo.png" alt="" /></a>
                        <a href="index.html" className="sticky-logo"><img src="assets/images/logo/logo-1.png" alt="" /></a>
                        <div className="ml-auto d-flex align-items-center">
                            <div className="main-menu">
                                <ul>
                                    <li className="current-menu-item"><a href="index.html"><i className="fa fa-home" aria-hidden="true"></i>&nbsp; Home</a></li>
                                    <li><a href="http://nammatechnologies.com" target="_blank"><i className="fa fa-address-book" aria-hidden="true"></i>&nbsp; About Us</a></li>
                                    <li><a href="service.html"><i className="fa fa-file-text" aria-hidden="true"></i> Services</a></li>
                                    <li><a href="service.html"><i className="fa fa-inr" aria-hidden="true"></i>&nbsp; Refer & Earn </a></li>
                                    <li><a href="enquiry.html"><i className="fa fa-headphones" aria-hidden="true"></i> &nbsp; Enquiry</a></li>
                                    <li><a href="#" data-target="#rtmodal-1" data-toggle="modal"><i className="far fa-user-circle"></i>&nbsp; Sign in | Join</a></li>
                                </ul>
                                <div className="mobile-menu">
                                    <div className="menu-click">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </div>
                            </div>
                            <div className="rt-nav-tolls d-flex align-items-center rt-mt-20" style={{ marginTop: -10 }}>
                                <span className="d-md-inline d-none"><a href="#"><img title="download App" src="../assets/images/ios.png" /> </a>
                                
                                {/* <a href="contact.html" className="rt-btn rt-gradient2 rt-rounded text-uppercase rt-Bshadow-1">Download IOS App
                                </a> */}
                                </span>
                                
                                <span className="d-md-inline d-none"><a href="#"><img title="download App" src="assets/images/play-store.png" /> </a>
                                {/* <a href="contact.html" className="rt-btn rt-gradient2 rt-rounded text-uppercase rt-Bshadow-1">Download App
                                </a> */}
                                </span>
                            </div>

                        </div>
                    </div>
                </nav>
            </div>

        </header>

{/* modal login signup start */}
<div className="modal fade" id="rtmodal-1" tabIndex="-1" role="dialog" aria-labelledby="rtmodal-1"
aria-hidden="true">
<div className="modal-dialog modal-dialog-centered rt-lgoinmodal " role="document">
    <div className="modal-content">
        <div className="modal-body">
            <div className="rt-modal-headr rt-mb-20 one">
                <img src="assets/images/logo/Logo-icon.png" alt="modal logo" draggable="false"/>
                <h4>Login to Namma Carnival</h4>
                <p>Log in to get in the moment updates on the things
                    that interest you.</p>
            </div>
            <div className="rt-modal-headr rt-mb-20 two">
                <img src="assets/images/logo/Logo-icon.png" alt="modal logo" draggable="false"/>
                <h4>Create your Account</h4>
                <p>Log in to get in the moment updates on the things that interest you.</p>
            </div>
            <div className="rt-modal-input one">
                <form action="#" className="rt-form">
                    <input type="text" className="form-control pill rt-mb-15" 
                     onChange={evt => this.updateInputValue(evt,"email")} placeholder="User name"/>
                    <input type="password" className="form-control pill rt-mb-15" 
                    onChange={evt => this.updateInputValue(evt,"password")} placeholder="Password"/>
                    <div className="form-group forgot-pass">
                        <div className="form-check">
                            <input className="form-check-input" type="checkbox" id="gridCheckss"/>
                            <label className="form-check-label" htmlFor="gridCheckss">
                                 Remember Password
                            </label><a  style={{float: right}}  data-target="#forgot" data-toggle="modal" data-dismiss="modal">Forgot Password</a>
                        </div>
                    </div>
                       
                    <a href="#" className="rt-btn rt-gradient pill d-block text-uppercase " onClick={() => this.handleLoginRequest()} style={{textAlign:center}}>Login</a>
                </form>
                <div className="ac-register">
                    <span>Don’t have an account? <a href="#" className="open-creatac">  &nbsp; Sign Up Now <i className="icofont-double-right"></i></a></span>
                </div>
            </div>
            <div className="rt-modal-input two">
                <form action="#" className="rt-form">
                    <input type="text" className="form-control pill rt-mb-15"
                     onChange={evt => this.updateInputValue(evt,"name")} placeholder="Name"/>
                    <input type="text" className="form-control pill rt-mb-15" 
                    onChange={evt => this.updateInputValue(evt,"email")} placeholder="Enter your mail address"/>
                     <input type="text" className="form-control pill rt-mb-15" 
                      onChange={evt => this.updateInputValue(evt,"phone")} placeholder="Contact Number"/>
                      <input type="text" className="form-control pill rt-mb-15" 
                      onChange={evt => this.updateInputValue(evt,"location")} placeholder="Location"/>
                    <input type="password" className="form-control pill rt-mb-15" 
                    onChange={evt => this.updateInputValue(evt,"password")} placeholder="Password"/>
                        <input type="password" className="form-control pill rt-mb-15"
                          onChange={evt => this.updateInputValue(evt,"confirmpassword")} placeholder="Confirm Password"/>
                    <div className="form-group forgot-pass">
                        <div className="form-check">
                            <input className="form-check-input" type="checkbox" id="gridCheck222"/>
                            <label className="form-check-label" htmlFor="gridCheck222">
                                By clicking "Sign up" you agree to our Terms of Service and Privacy Policy
                            </label>
                        </div>
                    </div>
                        <a href="#" className="rt-btn rt-gradient pill d-block text-uppercase " 
                        style={{textAlign:center}} onClick={() => this.handleRegistrationData()} data-target="#forgot-otp" data-toggle="modal" data-dismiss="modal">Signup</a>
                </form>
                <div className="ac-register">
                    <span>Already have an account? <a href="#" >&nbsp;  LOGIN <i className="icofont-double-right"></i></a></span>
                </div>
            </div>
            <div className="rt-modal-footer">
                <span>Or</span>
                <h4>Sign Up with social media</h4>
                <ul className="rt-social rt-circle-style2">
            
                    <li><a href="#"><i className="icofont-facebook"></i></a></li>
                    <li><a href="#"><i className="fa fa-google"></i></a></li>
                    
                </ul>
            </div>
        </div>
    </div>
</div>
</div>
{/* modal login signup end */}

{/* <!-- Modal forgot pwd start--> */}
<div id="forgot" className="modal fade" role="dialog">
<div className="modal-dialog">

{/* <!-- Modal content--> */}
<div className="modal-content">
  <div className="modal-header">
    <button type="button" className="close" data-dismiss="modal" style={{float:right}}>&times;<br/></button>
     <div className="rt-modal-headr rt-mb-20 one center ">
               
                <br/><h5 style={{textAlign:center}}>Enter Phone Number for Reset Password</h5>
            </div>
  </div>
  <div className="modal-body">
    <div className="rt-modal-input one">
                <form action="#" className="rt-form">
                    <input type="text" className="form-control pill rt-mb-15"  onChange={evt => this.updateInputValue(evt,"phone")} placeholder="Enter phone numer"/>
                        <a href="#" className="rt-btn rt-gradient pill d-block text-uppercase " 
                        style={{textAlign:center}}  data-target="#forgot-otp" data-toggle="modal"  onClick={() => this.sendotp()} data-dismiss="modal">Continue</a>
                </form>
            </div>
  </div>
</div>
</div>
</div>
{/* <!-- Modal forgot pwd end--> */}

{/* <!-- Modal Enter OTP for Verification start--> */}
<div id="forgot-otp" className="modal fade" role="dialog">
<div className="modal-dialog">

{/* <!-- Modal content--> */}
<div className="modal-content">
  <div className="modal-header">
    <button type="button" className="close" data-dismiss="modal" style={{float:right}}>&times;<br/></button>
     <div className="rt-modal-headr rt-mb-20 one center ">
               
                <br/><h5 style={{textAlign:center}}>Enter OTP for Verification</h5>
            </div>
  </div>
  <div className="modal-body">
    <div className="rt-modal-input one">
                <form action="#" className="rt-form">
                    <input type="text" className="form-control pill rt-mb-15"  onChange={evt => this.updateInputValue(evt,"OTP")} placeholder="Enter OTP"/>
                    <a href="#" className="rt-btn rt-gradient2 rt-rounded text-uppercase rt-Bshadow-1" style={mystyle} onClick={() => this.sendotp()}>Resend OTP</a>
                    
                        <a href="#" className="rt-btn rt-gradient pill d-block text-uppercase " 
                         style={{textAlign:center}} data-target="#password" data-toggle="modal" 
                          onClick={() => this.verifyotp()} data-dismiss="modal">Continue</a>
                </form>
               </div>
            </div>
          </div>
         </div>
      </div>
        {/* <!-- Modal Enter OTP for Verification ends--> */} 
    </>
);
    }
  }
  export default Header;

// const HeaderFunction = () => {
//     const right = "right";
//     const center = "center";
//     const mystyle = {
//         padding:"10px 15px",
//         margin:"10px",
//         marginLeft:"35%"

//       };
//     return (
//         <>
//             <header className="rt-site-header  rt-fixed-top white-menu">
//                 <div className="main-header rt-sticky">
//                     <nav className="navbar">
//                         <div className="container1 container">
//                             <a href="index.html" className="brand-logo"><img src="assets/images/logo/logo.png" alt="" /></a>
//                             <a href="index.html" className="sticky-logo"><img src="assets/images/logo/logo-1.png" alt="" /></a>
//                             <div className="ml-auto d-flex align-items-center">
//                                 <div className="main-menu">
//                                     <ul>
//                                         <li className="current-menu-item"><a href="index.html"><i className="fa fa-home" aria-hidden="true"></i>&nbsp; Home</a></li>
//                                         <li><a href="http://nammatechnologies.com" target="_blank"><i className="fa fa-address-book" aria-hidden="true"></i>&nbsp; About Us</a></li>
//                                         <li><a href="service.html"><i className="fa fa-file-text" aria-hidden="true"></i> Services</a></li>
//                                         <li><a href="service.html"><i className="fa fa-inr" aria-hidden="true"></i>&nbsp; Refer & Earn </a></li>
//                                         <li><a href="enquiry.html"><i className="fa fa-headphones" aria-hidden="true"></i> &nbsp; Enquiry</a></li>
//                                         <li><a href="#" data-target="#rtmodal-1" data-toggle="modal"><i className="far fa-user-circle"></i>&nbsp; Sign in | Join</a></li>
//                                     </ul>
//                                     <div className="mobile-menu">
//                                         <div className="menu-click">
//                                             <span></span>
//                                             <span></span>
//                                             <span></span>
//                                         </div>
//                                     </div>
//                                 </div>
//                                 <div className="rt-nav-tolls d-flex align-items-center rt-mt-20" style={{ marginTop: -10 }}>
//                                     <span className="d-md-inline d-none"><a href="#"><img title="download App" src="../assets/images/ios.png" /> </a>
                                    
//                                     {/* <a href="contact.html" className="rt-btn rt-gradient2 rt-rounded text-uppercase rt-Bshadow-1">Download IOS App
//                                     </a> */}
//                                     </span>
                                    
//                                     <span className="d-md-inline d-none"><a href="#"><img title="download App" src="assets/images/play-store.png" /> </a>
//                                     {/* <a href="contact.html" className="rt-btn rt-gradient2 rt-rounded text-uppercase rt-Bshadow-1">Download App
//                                     </a> */}
//                                     </span>
//                                 </div>

//                             </div>
//                         </div>
//                     </nav>
//                 </div>

//             </header>

// {/* modal login signup start */}
// <div className="modal fade" id="rtmodal-1" tabindex="-1" role="dialog" aria-labelledby="rtmodal-1"
//     aria-hidden="true">
//    <div className="modal-dialog modal-dialog-centered rt-lgoinmodal " role="document">
//         <div className="modal-content">
//             <div className="modal-body">
//                 <div className="rt-modal-headr rt-mb-20 one">
//                     <img src="assets/images/logo/Logo-icon.png" alt="modal logo" draggable="false"/>
//                     <h4>Login to Namma Carnival</h4>
//                     <p>Log in to get in the moment updates on the things
//                         that interest you.</p>
//                 </div>
//                 <div className="rt-modal-headr rt-mb-20 two">
//                     <img src="assets/images/logo/Logo-icon.png" alt="modal logo" draggable="false"/>
//                     <h4>Create your Account</h4>
//                     <p>Log in to get in the moment updates on the things that interest you.</p>
//                 </div>
//                 <div className="rt-modal-input one">
//                     <form action="#" className="rt-form">
//                         <input type="text" className="form-control pill rt-mb-15" placeholder="User name"/>
//                         <input type="password" className="form-control pill rt-mb-15" placeholder="Password"/>
//                         <div className="form-group forgot-pass">
//                             <div className="form-check">
//                                 <input className="form-check-input" type="checkbox" id="gridCheckss"/>
//                                 <label className="form-check-label" htmlFor="gridCheckss">
//                                      Remember Password
//                                 </label><a href="#" style={{float: right}}  data-target="#forgot" data-toggle="modal" data-dismiss="modal">Forgot Password</a>
//                             </div>
//                         </div>
						   
//                             <a href="account.html" className="rt-btn rt-gradient pill d-block text-uppercase " style={{textAlign:center}}>Login</a>
//                     </form>
//                     <div className="ac-register">
//                         <span>Don’t have an account? <a href="#" className="open-creatac">  &nbsp; Sign Up Now <i className="icofont-double-right"></i></a></span>
//                     </div>
//                 </div>
//                 <div className="rt-modal-input two">
//                     <form action="#" className="rt-form">
//                         <input type="text" className="form-control pill rt-mb-15" placeholder="Name"/>
//                         <input type="text" className="form-control pill rt-mb-15" placeholder="Enter your mail address"/>
// 						 <input type="text" className="form-control pill rt-mb-15" placeholder="Contact Number"/>
// 						  <input type="text" className="form-control pill rt-mb-15" placeholder="Location"/>
//                         <input type="password" className="form-control pill rt-mb-15" placeholder="Password"/>
// 						    <input type="password" className="form-control pill rt-mb-15" placeholder="Confirm Password"/>
//                         <div className="form-group forgot-pass">
                           
//                             <div className="form-check">
//                                 <input className="form-check-input" type="checkbox" id="gridCheck222"/>
//                                 <label className="form-check-label" htmlFor="gridCheck222">
//                                     By clicking "Sign up" you agree to our Terms of Service and Privacy Policy
//                                 </label>
//                             </div>
//                         </div>
//                             <a href="#" className="rt-btn rt-gradient pill d-block text-uppercase " style={{textAlign:center}} data-target="#otp" data-toggle="modal" data-dismiss="modal">Signup</a>
//                     </form>
//                     <div className="ac-register">
//                         <span>Already have an account? <a href="#" >&nbsp;  LOGIN <i className="icofont-double-right"></i></a></span>

//                     </div>
//                 </div>
//                 <div className="rt-modal-footer">
//                     <span>Or</span>
//                     <h4>Sign Up with social media</h4>
//                     <ul className="rt-social rt-circle-style2">
                
//                         <li><a href="#"><i className="icofont-facebook"></i></a></li>
//                         <li><a href="#"><i className="fa fa-google"></i></a></li>
                        
//                     </ul>
//                 </div>
//             </div>
//         </div>
//     </div>
// </div>
// {/* modal login signup end */}

// {/* <!-- Modal forgot pwd start--> */}
// <div id="forgot" className="modal fade" role="dialog">
//   <div className="modal-dialog">

//     {/* <!-- Modal content--> */}
//     <div className="modal-content">
//       <div className="modal-header">
//         <button type="button" className="close" data-dismiss="modal" style={{float:right}}>&times;<br/></button>
//          <div className="rt-modal-headr rt-mb-20 one center ">
                   
//                     <br/><h5 style={{textAlign:center}}>Enter Phone Number for Reset Password</h5>
//                 </div>
//       </div>
//       <div className="modal-body">
//         <div className="rt-modal-input one">
//                     <form action="#" className="rt-form">
//                         <input type="text" className="form-control pill rt-mb-15" placeholder="Enter phone numer"/>
//                             <a href="#" className="rt-btn rt-gradient pill d-block text-uppercase " style={{textAlign:center}}  data-target="#forgot-otp" data-toggle="modal" data-dismiss="modal">Continue</a>
//                     </form>
                    
//                 </div>
//       </div>
//     </div>
//   </div>
// </div>
// {/* <!-- Modal forgot pwd end--> */}

// {/* <!-- Modal Enter OTP for Verification start--> */}
// <div id="forgot-otp" className="modal fade" role="dialog">
//   <div className="modal-dialog">

//     {/* <!-- Modal content--> */}
//     <div className="modal-content">
//       <div className="modal-header">
//         <button type="button" className="close" data-dismiss="modal" style={{float:right}}>&times;<br/></button>
//          <div className="rt-modal-headr rt-mb-20 one center ">
                   
//                     <br/><h5 style={{textAlign:center}}>Enter OTP for Verification</h5>
                    
//                 </div>
//       </div>
//       <div className="modal-body">
//         <div className="rt-modal-input one">
//                     <form action="#" className="rt-form">
//                         <input type="text" className="form-control pill rt-mb-15" placeholder="Enter OTP"/>
//                         <a href="#" className="rt-btn rt-gradient2 rt-rounded text-uppercase rt-Bshadow-1" style={mystyle}>Resend OTP</a>
                        
//                             <a href="#" className="rt-btn rt-gradient pill d-block text-uppercase " style={{textAlign:center}} data-target="#password" data-toggle="modal" data-dismiss="modal">Continue</a>
//                     </form>
                    
//                 </div>
//       </div>
     
//     </div>

//   </div>
// </div>
//   {/* <!-- Modal Enter OTP for Verification ends--> */}

  
//         </>
//     );
// }
// export default Header;