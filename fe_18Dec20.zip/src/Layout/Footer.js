import React from "react";

// class Footer 
const Footer = () => {
    return (

<section className="rt-site-footer" data-scrollax-parent="true">
  <div className="rt-shape-emenetns-1" style={{backgroundImage: "url(assets/images/shape-elements/shape-4.png)"}} data-scrollax="properties: { translateY: '340px' }"></div>
    <div className="footer-top rtbgprefix-cover" style={{backgroundImage: "url(assets/images/backgrounds/footerbg.png)"}}>
        <div className="footer-subscripbe-box wow fade-in-bottom">
           <div className="container">
               <div className="row">
                   <div className="col-xl-8 col-lg-10 mx-auto text-center">
                        <div className="rt-section-title-wrapper text-white">
                            <h2 className="rt-section-title">
                                <span>Newsletter</span>
                        
                                Get The Latest news
                            </h2>
                            {/* <!-- /.rt-section-title --> */}
                            <p>
                                Get the latest travel inspirations and deals from Emigrar semimonthly with your email. You can
                                unsubscribe at any time. Your privacy & personal information will be treated.
                            </p>
                        </div>
                        {/* <!-- /.rt-section-title-wrapper --> */}
                   </div>
                   {/* <!-- /.col-lg-7 --> */}
               </div>
               {/* <!-- /.row --> */}
            <div className="section-title-spacer"></div>
            {/* <!-- /.section-title-spacer --> */}
            <div className="row">
                <div className="col-lg-7 mx-auto">
                    <div className="input-group mb-5">
                        <input type="text" className="form-control" placeholder="Enter your email address" aria-describedby="button-addon2"/>
                        <div className="input-group-append">
                            <button className="btn" type="button" id="button-addon2">Subcribe Now</button>
                        </div>
                    </div>
                    {/* <!-- end input gorup --> */}
                </div>
                {/* <!-- /.col-lg-7 --> */}
            </div>
            {/* <!-- /.row --> */}
               <div className="rt-dot-divider"></div>
               {/* <!-- /.rt-dot-divider --> */}
           </div>
           {/* <!-- /.container --> */}
        </div>
		{/* <!-- /.footer-subscripbe-box --> */}
        <div className="container">
            <div className="row">
                <div className="col-lg-3 col-md-6">
                    <div className="rt-single-widget wow fade-in-bottom" data-wow-duration="1s">
                        <h3 className="rt-footer-title">Other Services</h3>
                        {/* <!-- /.rt-footer-title --> */}
                        <ul className="rt-usefulllinks">
                          
                            <li><a href="http://nammamatrimony.in" target="_blank">Namma Matrimony</a></li>
                            <li><a href="http://nammamandapam.com" target="_blank">Namma Mandapam</a></li>
                            <li><a href="http://nammacarnival.com" target="_blank">Namma Carnival</a></li>
                            <li><a href="http://nammashopify.com" target="_blank">Namma Shopify</a></li>
                            <li><a href="http://nammaculture.com" target="_blank">Namma Culture</a></li>

                        </ul>

                    </div>
                    {/* <!-- /.rt-single-widge --> */}
                </div>
                {/* <!-- /.col-lg-3--> */}
                <div className="col-lg-3 col-md-6">
                    <div className="rt-single-widget wow fade-in-bottom" data-wow-duration="1.5s">
                        <h3 className="rt-footer-title">Location</h3>
                        <ul className="rt-usefulllinks">
                            <li><a href="#">Krisan Business Centre, Mayflower Valencia, 3B, 7th FLOOR, Old/New 1264B, Avinashi Road, (Between KFC and Ford Showroom) Nava India, Coimbatore – 641004</a></li>
                           
                        </ul>
                    </div>
                    {/* <!-- /.rt-single-widget --> */}
                </div>
                {/* <!-- /.col-lg-3--> */}
                <div className="col-lg-3 col-md-6">
                    <div className="rt-single-widget wow fade-in-bottom" data-wow-duration="2s">
                        <h3 className="rt-footer-title">
                            Contact Us
                        </h3>
                        <ul className="rt-usefulllinks">
                        
                            <li><a href="#">+91-99944 79923</a></li>
                            <li><a href="#">info@nammatechnology.com</a></li>
                            
                        </ul>
                        {/* <!-- /.rt-usefulllinks --> */}
						<ul>
<li><a href="https://www.facebook.com/nammacarnival.nammacarnival.1" target="_blank"><i className="fa fa-facebook"></i></a>
<a href="https://twitter.com/nammacarnival" target="_blank"><i className="fa fa-twitter"></i></a>
<a href="https://www.youtube.com/channel/UCcSyzL61X16AKniLNnsoGDQ?view_as=subscriber" target="_blank"><i className="fa fa-youtube-play"></i></a>
<a href="https://www.linkedin.com/in/namma-carnival-4ba5591a5/" target="_blank"><i className="fa fa-linkedin"></i></a>
<a href="https://www.instagram.com/namma_carnival/" target="_blank"><i className="fa fa-instagram"></i></a></li>
</ul>
                    </div>
                    {/* <!-- end single widget --> */}
                </div>
                {/* <!-- /.col-lg-3--> */}
                <div className="col-lg-3 col-md-6">
                    <div className="rt-single-widget wow fade-in-bottom" data-wow-duration="2.5s">
                        <h3 className="rt-footer-title">
                           International Office
                        </h3>
                        <ul className="rt-usefulllinks">
                            <li><a href="#">Mega woodlands, 39 Woodlands close Singapore - 737856.</a></li>
                            <li><a href="#">Goldparmänenweg 4, 64297 Darmstadt, Germany</a></li>
                           
                        </ul> 
                        {/* <!-- /.rt-usefulllinks --> */}
                    </div>
                    {/* <!-- end single widget --> */}
                </div>
                {/* <!-- /.col-lg-3--> */}
            </div>
            {/* <!-- /.row --> */}
        </div>
        {/* <!-- /.container --> */}
    </div>
    {/* <!-- /.footer-top --> */}
    <div className="footer-bottom">
        <div className="container">
            <div className="row">
                <div className="col-lg-12 text-center text-lg-left">
                <div className="copy-text wow fade-in-bottom" data-wow-duration="1s" style={{textAlign: "center"}}>
                    Copyright © 2020.<a href="#">Namma Technologies (P) LTD</a> All Rights Reserved.
                </div>
                {/* <!-- /.copy-text --> */}
                </div>
                {/* <!-- /.col-lg-6 --> */}
               
            </div>
            {/* <!-- /.row --> */}
        </div>
        {/* <!-- /.container --> */}
    </div>
    {/* <!-- /.footer-bottom --> */}
</section>

    );
}
export default Footer;