import Footer from './Layout/Footer';
import Header from './Layout/Header';

function App() {
  return (
    <div className="App">
        <Header/>

        <section className="rt-banner-area">
          <div className="single-rt-banner rt-banner-height" style={{backgroundColor:'#6155c2'}}>
          {/* <div className="single-rt-banner rt-banner-height" style={{backgroundImage:`url(${bgimg})`}}> */}

          </div>
        </section>

        <Footer/>
    </div>
  );
}

export default App;